#include <iostream>
#include <unordered_map>
#include <vector>

using namespace std;

void printUniqueElements(const vector<int>& arr) {
    unordered_map<int, bool> uniqueElements;
    cout << "Các phần tử khác nhau của mảng: ";
    for (int i = 0; i < arr.size(); i++) {
        if (uniqueElements.find(arr[i]) == uniqueElements.end()) {
            uniqueElements[arr[i]] = true;
            cout << arr[i] << " ";
        }
    }
    cout << endl;
}

void printMostFrequentElement(const vector<int>& arr) {
    unordered_map<int, int> frequency;
    int maxFreq = 0;
    int mostFrequentElement = 0;
    for (int i = 0; i < arr.size(); i++) {
        frequency[arr[i]]++;
        if (frequency[arr[i]] > maxFreq) {
            maxFreq = frequency[arr[i]];
            mostFrequentElement = arr[i];
        }
    }
    cout << "Phần tử xuất hiện nhiều lần nhất: " << mostFrequentElement << endl;
}

void printLongestIncreasingSubarray(const vector<int>& arr) {
    int maxLength = 1;
    int currentLength = 1;
    int startIndex = 0;
    int endIndex = 0;
    for (int i = 1; i < arr.size(); i++) {
        if (arr[i] > arr[i - 1]) {
            currentLength++;
        } else {
            if (currentLength > maxLength) {
                maxLength = currentLength;
                endIndex = i - 1;
                startIndex = endIndex - maxLength + 1;
            }
            currentLength = 1;
        }
    }
    if (currentLength > maxLength) {
        maxLength = currentLength;
        endIndex = arr.size() - 1;
        startIndex = endIndex - maxLength + 1;
    }
    cout << "Đoạn tăng dần dài nhất: ";
    for (int i = startIndex; i <= endIndex; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
}

void printLargestSumSubarray(const vector<int>& arr) {
    int maxSum = arr[0];
    int currentSum = arr[0];
    for (int i = 1; i < arr.size(); i++) {
        currentSum = max(arr[i], currentSum + arr[i]);
        maxSum = max(maxSum, currentSum);
    }
    cout << "Đoạn liên tiếp có tổng lớn nhất: " << maxSum << endl;
}

int main() {
    vector<int> arr = {-1, 2, -3, -4, 5, 2, 3, 4, 5, 6, 7, 8, -9, 10, 1, 2, 3, 4, 5};
    
    printUniqueElements(arr);
    printMostFrequentElement(arr);
    printLongestIncreasingSubarray(arr);
    printLargestSumSubarray(arr);
    
    return 0;
}
